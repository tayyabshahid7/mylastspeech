import React from 'react';
import history from '../../utils/history';

import './resend.scss';

interface ResendProps {

}
interface ResendState {

}

class Resend extends React.Component<ResendProps, ResendState> {

    submitForm = (e:any) => {
        e.preventDefault();
        history.push("/success");   
    }

    render() {
        return (
            <div className="container login-container resend">
                <div className="align-items-center d-flex justify-content-center row custom-login">
                    <div className=" col-lg-6 col-12  login-form">
                        <form onSubmit={this.submitForm.bind(this)}>
                            <a>Please go to your email and verify the address you
                            have used. If you do not see it check your junk folder.</a>
                            <div className="form-group mt-5 mb-5">
                                <input type="text" className="form-control" placeholder="Verification code" value="" />
                            </div>
                            <div className="resend-text mb-5">Resend</div>
                            <div className="form-group custom-submit ">
                                <button className="btn btnSubmit" type="submit">
                                    <i className=" fa fa-long-arrow-right" aria-hidden="true"></i>
                                </button>                            
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        );
    }
}

export default Resend;

