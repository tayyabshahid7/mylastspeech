import React from 'react';
import './dashboard.scss';

interface DashboardProps {

}
interface DashboardState {

}

class Dashboard extends React.Component<DashboardProps, DashboardState> {

    render() {
        return (
            <div className="container login-container user-dash">
                <div className="align-items-center d-flex justify-content-center row custom-login">
                    <div className=" col-lg-6 col-12  login-form ">
                        <form>
                            <div className="form-group">
                                <div className="custom-text-field">
                                    <textarea rows={15} placeholder="Start Typing"></textarea>
                                </div>
                            </div>

                            <div className="form-group custom-submit ">
                                <button className="btn btnSubmit" type="submit">
                                    <i className="fa fa-spotify" aria-hidden="true"></i> &nbsp;
                                <span>+ Spotify song</span>
                                </button>
                            </div>
                            <div className="after-section ">
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        );
    }
}

export default Dashboard;

