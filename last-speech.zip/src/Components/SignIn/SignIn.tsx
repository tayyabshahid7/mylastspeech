import React from 'react';
import history from '../../utils/history';

import './signin.scss';

interface SignInProps {

}
interface SignInState {

}

class SignIn extends React.Component<SignInProps, SignInState> {
   
    submitForm = (e:any) => {
        e.preventDefault();
        history.push("/success");   
    }

    render() {
        return (
            <div className="container login-container">
                <div className="align-items-center d-flex justify-content-center row custom-login">
                    <div className="  col-lg-6 login-form">
                        <form onSubmit={this.submitForm.bind(this)}>
                            <div className="form-group">
                                <label>Email</label>
                                <input type="text" className="form-control" placeholder="Enter Your Email *" value="" />
                            </div>
                            <div className="form-group">
                                <label>Password</label>
                                <input type="password" className="form-control" placeholder="Enter Your Password *" value="" />
                            </div>
                            <div className="form-group mt-5 pb-4">
                                <a href="#" className="ForgetPwd">Forget Password?</a>
                            </div>
                            <div className="form-group custom-submit ">
                                <button className="btn btnSubmit" type="submit"><i className=" fa fa-long-arrow-right" aria-hidden="true"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        );
    }
}

export default SignIn;

