import React from "react";
import "./sidenavbar.scss";

class SideNavBar extends React.Component {
  state = {
    state: {
      showNav: false
    }
  }

  openNavClick = (e:any) => {
    e.preventDefault()
    this.openNav()
  }

  closeNavClick = (e:any)  => {
    e.preventDefault()
    this.closeNav()
  }

  openNav = () => {
    this.setState({
      showNav: true
    })

    document.addEventListener("keydown", this.handleEscKey)
  }
  closeNav = () => {
    this.setState({
      showNav: false
    })

    document.removeEventListener("keydown", this.handleEscKey)
  }

  handleEscKey = (e:any)  => {
    if (e.key === "Escape") {
      this.closeNav()
    }
  }

  render() {
    const { showNav } :any = this.state
    let sideNavStyle = { width: showNav ? "100%" : "0%" }


    return (
        <div id="sideNavBar">
           
                    <span onClick={this.openNavClick} className="open-nav" style={{color:"white",zIndex:999999}}>
                        <i className="fa fa-question-circle question-mark" aria-hidden="true"></i>
                    </span>
                    {/* <div
                    onClick={this.navCoverClick.bind(this)}
                    className="nav-cover"
                    style={navCoverStyle}
                    /> */}
                    <div style={sideNavStyle} className={showNav?"navBar":''}>
                        <div  className={"side-nav ".concat(showNav? "d-block" : "d-none")} style={{width:"25%"}}>
                            <a href="#" onClick={this.closeNavClick} className="close-nav">
                                &times;
                            </a>
                            <a href="#">About</a>
                            <a href="#">Services</a>
                            <a href="#">Clients</a>
                            <a href="#">Contact</a>
                        </div>
                        <div  className={"side-nav-overlay ".concat(showNav? "d-block" : "d-none")} style={{width:"75%"}}>

                        </div>
                    </div>
                    
   
        </div>
     )
  }
}

export default SideNavBar;
