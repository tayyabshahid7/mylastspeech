import React from 'react';
import './tabs.scss';

interface TabsProps {

}
interface TabsState {
    activeTab:string,
}

class Tabs extends React.Component<TabsProps, TabsState> {

    state = {
        activeTab: 'accesspage'
    }
    toggleActiveTab = (tab:string,e:any)=>{
        this.setState({
            activeTab : tab,
        })
    }
    render() {

        return (
           <div>
               <div className="container login-container tab-page ">
                    <div className="align-items-center d-flex justify-content-center row tabs-section custom-login">
                        <div className="col-12 col-lg-10 login-form mb-5 pb-5 tabs-card">
                            <div className="col-md-3 float-left  pb-5 left-sec">
                                <div className="tab">
                                    <button className={"tablinks ".concat(this.state.activeTab === "accesspage" ? 'active': '')} onClick={this.toggleActiveTab.bind(this,'accesspage')} id="defaultOpen">Who can access<br/> my page</button>
                                    <button className={"tablinks ".concat(this.state.activeTab === "security" ? 'active': '')} onClick={this.toggleActiveTab.bind(this,'security')} >Security questions</button>
                                    <button className={"tablinks ".concat(this.state.activeTab === "profile" ? 'active': '')} onClick={this.toggleActiveTab.bind(this,'profile')} >Profile</button>
                                </div>
                            </div>

                            <div className="col-md-9 float-left pb-5 content-sec ">
                                <div id="London" className="tabcontent">
                                    <p>Add the email address’s of people you wish to allow access your <br/> speech, you need to add at least 3</p>
                                    <div className="form-group">
                                        <input type="email" className="form-control" placeholder="Email 1" value="" />
                                    </div>
                                    <div className="form-group">
                                        <input type="email" className="form-control" placeholder="Email 2" value="" />
                                    </div>
                                    <div className="form-group">
                                        <input type="email" className="form-control" placeholder="Email 3" value="" />
                                    </div>
                                    <div className="form-group add-btn">
                                        <a href="#">+ Add</a>
                                    </div>
                                </div>
                                <div id="Paris" className="tabcontent">
                                    <p>Add questions that we will ask your loved ones when <br/>they try to access your speech</p>
                                </div>
                                <div id="Tokyo" className="tabcontent profile-section">
                                    <img src="assets/images/img_avatar.png" alt="Avatar"/>&nbsp; &nbsp; &nbsp; &nbsp;<span>Change</span>
                                    <form>
                                        <div className="form-group">
                                            <label>Full Name</label>
                                            <input type="text" className="form-control" placeholder="Enter Your Name *" value="" />
                                        </div>
                                        <div className="form-group">
                                            <label>Date of Birth</label>
                                            <input type="date" className="form-control" placeholder=" mm/dd/yy" value="" />
                                        </div>
                                        <div className="form-group">
                                            <label>Email</label>
                                            <input type="email" className="form-control" placeholder="Email *" value="" />
                                        </div>
                                        <div className="form-group">
                                            <label>Password</label>
                                            <input type="password" className="form-control" placeholder="Password *" value="" />
                                        </div>
                                    </form>
                                    
                            </div>
                            </div>
                            <div className="row bottom-card">
                                <span>More</span>
                            </div>
                        </div>
                    </div>

                </div>
                <div className="col-8 d-flex justify-content-center upper-list pb-5 mb-3">
                            <a href="#">My Speech</a>
                            <a href="#" className="active">Settings</a>
                </div>
           </div>
        );
    }
}

export default Tabs;

