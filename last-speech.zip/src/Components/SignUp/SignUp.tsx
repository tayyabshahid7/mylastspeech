import React from 'react';
import './signup.scss';
import history from '../../utils/history';

interface SignUpProps {
}
interface SignUpState {
    isResend:boolean,
}

class SignUp extends React.Component<SignUpProps, SignUpState> {

    state = {
        isResend:false,
    }

    submitForm = (e:any) => {
        e.preventDefault();
        history.push("/resend");   
    }
    
    render() {
     
        return (
            <div className="container login-container sign-up">
            <div className="align-items-center d-flex justify-content-center row custom-login">
                <div className=" col-lg-6 col-12  login-form">
                    <form onSubmit={this.submitForm.bind(this)}>
                        <div className="form-group">
                            <label>Full Name</label>
                            <input type="text" className="form-control" placeholder="Enter Your Name *" value="" />
                        </div>
                        <div className="form-group">
                            <label>Email</label>
                            <input type="email" className="form-control" placeholder="Email *" value="" />
                        </div>
                        <div className="form-group">
                            <label>Password</label>
                            <input type="password" className="form-control" placeholder="Password *" value="" />
                        </div>
                        <div className="form-group">
                            <label>Repeat Password</label>
                            <input type="password" className="form-control" placeholder="Repeat Password *" value="" />
                        </div>
                        <div className="form-group mt-5 pb-4 form-field">
                            <input type="checkbox" name="vehicle1" value="Bike"/> I agree to
                            <a href="#">privacy policy</a> and <a href="#">terms of service</a><br/>
                        </div>
                        <div className="form-group custom-submit ">
                            <button className="btn btnSubmit" type="submit"> <i className=" fa fa-long-arrow-right" aria-hidden="true"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        
        
        
        </div>
             
        );
    }
}

export default SignUp;

