import React, { useState } from 'react';
import Routes from './Components/Routes/Routes';

const App: React.FC = () => {
  
  return ( 
        <Routes/>
    )
}
export default App;
